const { app, BrowserWindow, ipcMain, dialog, Menu, shell } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow = null;
let screenshotProtectionEnabled = true;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1366,
    height: 850,
    minWidth: 1024,
    minHeight: 700,
    title: 'Hadi Studio & Events - Management System',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    backgroundColor: '#020617',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true,
      spellcheck: false
    }
  });

  // Enable platform screenshot privacy protection if supported
  try {
    if (mainWindow.setContentProtection) {
      mainWindow.setContentProtection(screenshotProtectionEnabled);
    }
  } catch (err) {
    console.warn('Screenshot protection not supported on this OS/hardware:', err);
  }

  // Determine whether to load dev server or built production files
  const isDev = process.env.NODE_ENV === 'development' || !app.isPackaged;
  if (isDev && process.env.ELECTRON_START_URL) {
    mainWindow.loadURL(process.env.ELECTRON_START_URL);
  } else if (isDev && fs.existsSync(path.join(__dirname, 'dist', 'index.html'))) {
    mainWindow.loadFile(path.join(__dirname, 'dist', 'index.html'));
  } else if (fs.existsSync(path.join(__dirname, 'dist', 'index.html'))) {
    mainWindow.loadFile(path.join(__dirname, 'dist', 'index.html'));
  } else {
    mainWindow.loadURL('http://localhost:3000');
  }

  // Handle external links safely
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https:') || url.startsWith('http:')) {
      shell.openExternal(url);
    }
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// App lifecycle
app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Secure IPC Handlers
ipcMain.handle('get-app-version', () => {
  return app.getVersion();
});

ipcMain.handle('toggle-screenshot-protection', (event, enable) => {
  screenshotProtectionEnabled = Boolean(enable);
  if (mainWindow && mainWindow.setContentProtection) {
    try {
      mainWindow.setContentProtection(screenshotProtectionEnabled);
      return { success: true, enabled: screenshotProtectionEnabled };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
  return { success: false, error: 'Not supported' };
});

ipcMain.handle('save-invoice-pdf', async (event, { base64Data, defaultFilename }) => {
  try {
    const { filePath, canceled } = await dialog.showSaveDialog(mainWindow, {
      title: 'Save Hadi Studio Invoice PDF',
      defaultPath: defaultFilename || 'HadiStudio_Invoice.pdf',
      filters: [{ name: 'PDF Documents', extensions: ['pdf'] }]
    });

    if (canceled || !filePath) return { success: false, canceled: true };

    const buffer = Buffer.from(base64Data, 'base64');
    fs.writeFileSync(filePath, buffer);
    return { success: true, filePath };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('export-csv-file', async (event, { csvContent, defaultFilename }) => {
  try {
    const { filePath, canceled } = await dialog.showSaveDialog(mainWindow, {
      title: 'Export Report CSV',
      defaultPath: defaultFilename || 'HadiStudio_Report.csv',
      filters: [{ name: 'CSV Files', extensions: ['csv'] }]
    });

    if (canceled || !filePath) return { success: false, canceled: true };

    fs.writeFileSync(filePath, csvContent, 'utf-8');
    return { success: true, filePath };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('backup-local-database', async (event, { jsonString, defaultFilename }) => {
  try {
    const { filePath, canceled } = await dialog.showSaveDialog(mainWindow, {
      title: 'Save Hadi Studio Database Backup',
      defaultPath: defaultFilename || `HadiStudio_Backup_${new Date().toISOString().slice(0, 10)}.json`,
      filters: [{ name: 'JSON Backup', extensions: ['json'] }]
    });

    if (canceled || !filePath) return { success: false, canceled: true };

    fs.writeFileSync(filePath, jsonString, 'utf-8');
    return { success: true, filePath };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('restore-local-database', async () => {
  try {
    const { filePaths, canceled } = await dialog.showOpenDialog(mainWindow, {
      title: 'Select Hadi Studio Backup File',
      filters: [{ name: 'JSON Backup', extensions: ['json'] }],
      properties: ['openFile']
    });

    if (canceled || !filePaths || filePaths.length === 0) return { success: false, canceled: true };

    const content = fs.readFileSync(filePaths[0], 'utf-8');
    return { success: true, data: JSON.parse(content), filename: path.basename(filePaths[0]) };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('print-thermal-receipt', async (event, htmlContent) => {
  // Silent print or standard print dialog
  if (mainWindow) {
    mainWindow.webContents.print({ silent: false, printBackground: true });
    return { success: true };
  }
  return { success: false, error: 'No active window' };
});
